<?php 
//if($_SESSION['AUTH_LOG']=='YES'){?>
<div class="app-sidebar sidebar-shadow">
          <?php //include "./../resources/views/template/part/site-brand.blade.php";?>
          <div class="app-header__menu"><span><button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav"><span class="btn-icon-wrapper"><i class="fa fa-ellipsis-v fa-w-6"></i></span></button></span></div>
          <div class="scrollbar-sidebar">
            <div class="app-sidebar__inner">
              <ul class="vertical-nav-menu">
            <?php if(Auth::user()->role_level==1){?>
            
                <li class="app-sidebar__heading">Menu Master</li>
                
                  <li><a href="<?php echo url('/admin');?>" class=""><i class="metismenu-icon pe-7s-home"></i>Beranda</a></li>
                    <li><a href="<?php echo url('/role');?>" class=""><i class="metismenu-icon pe-7s-settings"></i>Role Access </a></li>
                    <li><a href="<?php echo url('/perusahaan');?>" class=""><i class="metismenu-icon pe-7s-wallet"></i>Data Perusahaan</a></li>
                    
                    
                    
                <?php }elseif(Auth::user()->role_level==2){?>
                
                <li class="app-sidebar__heading">Menu</li>
                 <li><a href="<?php echo url('/perusahaan');?>" class="<?php //if($_GET['page']=='perusahaan'){echo 'mm-active';}?>"><i class="metismenu-icon  pe-7s-home"></i>Data Perusahaan</a></li>
                    
                <li ><a href="<?php echo url('/karyawan');?>" class=""><i class="metismenu-icon pe-7s-add-user"></i>Data Karyawan</a></li>
                <li><a href="<?php echo url('/akunkaryawan');?>" class="<?php //if($_GET['page']=='akun-karyawan'){echo 'mm-active';}?>"><i class="metismenu-icon pe-7s-user"></i>Akun Karyawan</a></li>
                <li><a href="<?php echo url('absensi');?>" class="<?php //if($_GET['page']=='akun-karyawan'){echo 'mm-active';}?>"><i class="metismenu-icon pe-7s-repeat"></i>Laporan Absensi</a></li>
                
                <?php }else{?>
Karyawan
<?php }?>
                 </ul>
              
            </div>
          </div>
        </div>
