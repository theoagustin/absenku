<div id="loadform">Loading...</div>
<script>
$(document).ready(function(e) {
	alert('test');
   $('#loadform').load('./base/role/data.php'); 
});
</script>