<div id="loadfile">Loading...</div>
<script>
$(document).ready(function(e) {
   $('#loadfile').load('./base/bagian/data.php'); 
});

</script>