<div id="loadfile">Loading...</div>
<script>
$(document).ready(function(e) {
   $('#loadfile').load('./base/karyawan/data.php'); 
});

</script>