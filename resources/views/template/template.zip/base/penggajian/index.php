<div id="loadfile">Loading...</div>
<script>
$(document).ready(function(e) {
   $('#loadfile').load('./base/penggajian/data.php'); 
});

</script>