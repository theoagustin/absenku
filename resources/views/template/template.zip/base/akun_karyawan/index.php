<div id="loadfile">Loading...</div>
<script>
$(document).ready(function(e) {
   $('#loadfile').load('./base/akun_karyawan/data.php'); 
});

</script>